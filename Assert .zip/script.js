function playSound(file) {
  let audio = new Audio("assets/" + file);
  audio.play();
}